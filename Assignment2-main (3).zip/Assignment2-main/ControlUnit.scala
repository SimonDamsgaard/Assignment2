import chisel3._
import chisel3.util._

class ControlUnit extends module{
  val io = Io(new Bundle{
    val opcode = Input(UInt(6.W)) //all opcodes are 6 bits long
    val aluOp = output(UInt(3.W))
    val aSel = output(UInt(3.W))
    val bSel = output(UInt(3.W))
    val writeSel = output(UInt(3.W))
    val writeEnable = output(Bool())
    val

  })
  //Opcode!!!
  val Add = 100000.U(6.W) // Add two values from two inputs
  val SUBI = 110010.U(6.W) //Subtrakt Immediate
  val MULI = 110011.U(6.W) //MULTIPLY immediate
  val LI = 010000.U(6.W) //LOAD Immediate
  val LD = 001001.U(6.W) // Load pixel value from one register to another
  val SD = 001010.U(6.W) // Save pixel value from one register to another
  val BEQ = 100101.U(6.W) //Compares two inputs to check if they are equal, thereafter declares where to jump




  switch(io.opcode){
    is(Add) {
      io.aluOp = 0
      io.writeEnable = true.b
      io.read = true.b
    }
    is(SUBI) {
      io.aluOp = 1
      io.writeEnable = true.b
    }
    is(MULI) {
      io.aluOp = 2
      io.writeEnable = true.b
    }
    is(BEQ) {
      io.aluOp = 3
      io.read = true.b //Read registers
      io.branch = true.b
      io.jump = true.b
    }
    is(LI) {
      io.aluOp = 4
      io.writeEnable = true.b
      io.read = true.b

    }
    is(LD){
      io.aluOp = 5
      io.writeEnable = true.b
      }
    is(SD){
      io.aluOp = 6
      io.writeEnable = true.b
    }

  }


}