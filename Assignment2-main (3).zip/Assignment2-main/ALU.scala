import chisel3._
import chisel3.util._


class ALU(width: Int) extends Module {
  val io = IO(new Bundle{
    val a = Input(UInt(width.W)) //input 1
    val b = Input(UInt(width.W)) // input 2
    val regMemoryAddress = Input(UInt(width.W))
    val aluControl = Input(UInt(3.W)) // input from the controller?
    val result = Output(UInt(width.W))
    val equal = Output(Bool())   // Equality flag




  })
  //default result
  val result = Wire(UInt(width.W))
  result := 0.U

  //logic for equality
  val isEqual = io.a == io.b

  switch(io.aluControl){
    is(0.U) { result:= io.a+io.b} // Addition
    is(1.U) { result := io.a-io.b} // Subtraktion
    is(2.U) { result := io.a*io.b} //Multiplikation
    is(3.U) {io.equal := isEqual } // Equality check
    is(4.U) {result := io.a+io.b}//Load immediate
    is(5.U) {}... //Load data
    is(6.U) {result}...//Save data
  }

  //outputs
  io.result := result
  io.equal := isEqual
}