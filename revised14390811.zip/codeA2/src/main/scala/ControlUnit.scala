import chisel3._
import chisel3.util._

class ControlUnit extends Module {
  val io = IO(new Bundle {
    val opcode = Input(UInt(6.W))         // All opcodes are 6 bits long
    val aluOp = Output(UInt(3.W))         // ALU operation selector
    val aSel = Output(UInt(3.W))          // Selector for operand a
    val bSel = Output(UInt(3.W))          // Selector for operand b
    val writeSel = Output(UInt(3.W))      // Selector for write register
    val writeEnable = Output(Bool())      // Write enable signal
    val readEnable = Output(Bool())       // Read enable signal
    val branch = Output(Bool())           // Branch enable signal
    val jump = Output(Bool())             // Jump enable signal, redundant, but whatever
  })

  // Define opcode values
  val ADD  = "100000".U(6.W) // Add two values from two inputs
  val ADDI = "110001".U(6.W) // Add Immediate
  val SUBI = "110010".U(6.W) // Subtract Immediate
  val MULI = "110011".U(6.W) // Multiply Immediate
  val LI   = "010000".U(6.W) // Load Immediate
  val LD   = "001001".U(6.W) // Load from memory
  val SD   = "001010".U(6.W) // Store to memory
  val BEQ  = "100101".U(6.W) // Branch if equal

  // Default values for outputs
  io.aluOp := 0.U
  io.writeEnable := false.B
  io.readEnable := false.B
  io.branch := false.B
  io.jump := false.B
  io.aSel := 0.U
  io.bSel := 0.U
  io.writeSel := 0.U

  // Control logic based on opcode
  switch(io.opcode) {
    is(ADD) {
      io.aluOp := 0.U                       // ALU operation for ADD
      io.writeEnable := true.B              // Enable write to the register file
      io.readEnable := true.B               // Enable reading from registers
    }
    is(ADDI) {
      io.aluOp := 1.U                       // ALU operation for ADDI (addition)
      io.writeEnable := true.B              // Enable write to the register file
      io.readEnable := true.B               // Enable reading from registers
      io.aSel := 3 //Register for ADDI
      io.writeSel := 4 //Destination Register for the Result
    }
    is(SUBI) {
      io.aluOp := 2.U                       // ALU operation for SUBI
      io.writeEnable := true.B              // Enable write to the register file
      io.readEnable := true.B               // Enable reading from registers
    }
    is(MULI) {
      io.aluOp := 3.U                       // ALU operation for MULI
      io.writeEnable := true.B              // Enable write to the register file
      io.readEnable := true.B               // Enable reading from registers
    }
    is(BEQ) {
      io.aluOp := 4.U                       // ALU operation for BEQ (comparison)
      io.readEnable := true.B               // Enable reading from registers
      io.branch := true.B                   // Set branch flag
      io.jump := true.B                     // Set jump flag for branching
    }
    is(LI) {
      io.aluOp := 5.U                       // ALU operation for LI (load immediate)
      io.writeEnable := true.B              // Enable write to the register file
    }
    is(LD) {
      io.aluOp := 6.U                       // ALU operation for LD (load from memory)
      io.writeEnable := true.B              // Enable write to the register file
    }
    is(SD) {
      io.aluOp := 7.U                       // ALU operation for SD (store to memory)
      io.readEnable := true.B               // Enable reading from registers
    }
  }
}
