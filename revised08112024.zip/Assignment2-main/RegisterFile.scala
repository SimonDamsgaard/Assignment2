import chisel3._
import chisel3.util._

class RegisterFile(numRegisters: Int, width: Int) extends Module {
  val io = IO(new Bundle {
    val aSel = Input(UInt(log2Ceil(numRegisters).W))      // Selector for output 'a'
    val bSel = Input(UInt(log2Ceil(numRegisters).W))      // Selector for output 'b'
    val writeSel = Input(UInt(log2Ceil(numRegisters).W))  // Selector for writing
    val writeData = Input(UInt(width.W))                  // Data to write
    val writeEnable = Input(Bool())                       // Write enable signal
    val a = Output(UInt(width.W))                         // Output for selected register 'a'
    val b = Output(UInt(width.W))                         // Output for selected register 'b'
  })

  // Define registers as a vector of registers, initialized to 0
  val registers = RegInit(VecInit(Seq.fill(numRegisters)(0.U(width.W))))

  // Read operations
  io.a := registers(io.aSel)
  io.b := registers(io.bSel)

  // Write operation
  when(io.writeEnable) {
    registers(io.writeSel) := io.writeData
  }
}
