import chisel3._
import chisel3.util._

class ALU(width: Int) extends Module {
  val io = IO(new Bundle {
    val opCode = Input(UInt(6.W))                // Operation code (6 bits)
    val in1 = Input(UInt(width.W))               // First operand (register or immediate)
    val in2 = Input(UInt(width.W))               // Second operand (register)
    val in3 = Input(UInt(width.W))               // Third operand (for ADD)
    val result = Output(UInt(width.W))           // ALU result
    val zero = Output(Bool())                    // Zero flag for branch instructions
    val branchTarget = Output(UInt(6.W))         // Branch target for BEQ
  })

  // Default values
  io.result := 0.U
  io.zero := false.B
  io.branchTarget := 0.U

  // Define ALU operations based on opCode
  switch(io.opCode) {
    is(0.U) {                             // ADD
      io.result := io.in1 + io.in2 + io.in3
    }
    is(1.U) {                             // ADDI
      io.result := io.in1 + io.in2                // in2 here is immediate value
    }
    is(2.U) {                             // SUBI
      io.result := io.in1 - io.in2                // in2 is immediate value
    }
    is(3.U) {                             // MULI
      io.result := io.in1 * io.in2                // in2 is immediate value
    }
    is(4.U) {                             // LI (Load Immediate)
      io.result := io.in1                         // in1 is immediate value loaded into target register
    }
    is(5.U) {                             // LD (Load from memory address)
      // Here, LD should be handled in the memory stage, so we don't do much in ALU
      io.result := io.in1                         // Placeholder for memory load (register address)
    }
    is(6.U) {                             // SD (Store to memory address)
      // SD also involves memory, typically controlled by Control Unit
      io.result := io.in1                         // Placeholder for memory store (value to store)
    }
    is(7.U) {                             // BEQ (Branch if Equal)
      io.zero := (io.in1 === io.in2)              // Set zero flag if registers are equal
      io.branchTarget := io.in3                   // Branch target address if in1 == in2
    }
    is(8.U) {                             // END (Halt execution)
      io.result := 0.U                            // Signal to halt CPU
    }
  }
}
