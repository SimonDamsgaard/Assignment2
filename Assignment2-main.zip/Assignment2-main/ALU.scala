import chisel3._
import chisel3.util._


class ALU(width: Int) extends Module {
  val io = IO(new Bundle{
    val a = Input(UInt(width.W)) //input 1
    val b = Input(UInt(width.W)) // input 2
    val aluControl = Input(UInt(3.W)) // input from the controller?
    val result = Output(UInt(width.W))
    val equal = Output(Bool())   // Equality flag



  })
  //default result
  val result = Wire(UInt(width.W))
  result := 0.U

  //logic for equality
  val isEqual = io.a == io.b

  switch(io.aluControl){
    is(0.U) { result:= io.a+io.b} // Addition
    is(1.U) { result := io.a-io.b} // Subtraktion
    is(2.U) { result := io.a*io.b} //Multiplikation
    is(3.U) {io.equal := isEqual } // Equality check
  }

  //outputs
  io.result := result
  io.equal := isEqual
}