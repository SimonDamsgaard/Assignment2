import chisel3._
import chisel3.util._

class RegisterFile(numRegisters: Int, width: Int) extends Module {
  val io = IO(new Bundle {
    val aSel = Input(UInt(log2Ceil(numRegisters).W))       // Selector for output 'a'
    val bSel = Input(UInt(log2Ceil(numRegisters).W))       // Selector for output 'b'
    val a = Output(UInt(width.W))                          // Output for selected register aSel
    val b = Output(UInt(width.W))                          // Output for selected register bSel
    val WriteData = Input(UInt(width.W))                   // Data to write
    val WriteSel = Input(UInt(log2Ceil(numRegisters).W))   // Selection for write register
    val WriteEnable = Input(Bool())                        // Write enable signal
  })

  // Define registers from reg0 to reg11
  val reg0 = RegInit(0.U(width.W))
  val reg1 = RegInit(0.U(width.W))
  val reg2 = RegInit(0.U(width.W))
  val reg3 = RegInit(0.U(width.W))
  val reg4 = RegInit(0.U(width.W))
  val reg5 = RegInit(0.U(width.W))
  val reg6 = RegInit(0.U(width.W))
  val reg7 = RegInit(0.U(width.W))
  val reg8 = RegInit(0.U(width.W))
  val reg9 = RegInit(0.U(width.W))
  val reg10 = RegInit(0.U(width.W))
  val reg11 = RegInit(0.U(width.W))

  // Default output assignments for `a` and `b`
  io.a := 0.U(width.W)
  io.b := 0.U(width.W)

  // Read logic for `a` output
  switch(io.aSel) {
    is(0.U) { io.a := reg0 }
    is(1.U) { io.a := reg1 }
    is(2.U) { io.a := reg2 }
    is(3.U) { io.a := reg3 }
    is(4.U) { io.a := reg4 }
    is(5.U) { io.a := reg5 }
    is(6.U) { io.a := reg6 }
    is(7.U) { io.a := reg7 }
    is(8.U) { io.a := reg8 }
    is(9.U) { io.a := reg9 }
    is(10.U) { io.a := reg10 }
    is(11.U) { io.a := reg11 }
  }

  // Read logic for `b` output
  switch(io.bSel) {
    is(0.U) { io.b := reg0 }
    is(1.U) { io.b := reg1 }
    is(2.U) { io.b := reg2 }
    is(3.U) { io.b := reg3 }
    is(4.U) { io.b := reg4 }
    is(5.U) { io.b := reg5 }
    is(6.U) { io.b := reg6 }
    is(7.U) { io.b := reg7 }
    is(8.U) { io.b := reg8 }
    is(9.U) { io.b := reg9 }
    is(10.U) { io.b := reg10 }
    is(11.U) { io.b := reg11 }
  }

  // Write logic: write `WriteData` to the selected register if `WriteEnable` is true
  when(io.WriteEnable) {
    switch(io.WriteSel) {
      is(0.U) { reg0 := io.WriteData }
      is(1.U) { reg1 := io.WriteData }
      is(2.U) { reg2 := io.WriteData }
      is(3.U) { reg3 := io.WriteData }
      is(4.U) { reg4 := io.WriteData }
      is(5.U) { reg5 := io.WriteData }
      is(6.U) { reg6 := io.WriteData }
      is(7.U) { reg7 := io.WriteData }
      is(8.U) { reg8 := io.WriteData }
      is(9.U) { reg9 := io.WriteData }
      is(10.U) { reg10 := io.WriteData }
      is(11.U) { reg11 := io.WriteData }
    }
  }
}
